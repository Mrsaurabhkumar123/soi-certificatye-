-- Test SQL Patch
SELECT 1;
